package Main;
import java.util.Scanner;

/* Entrega da prova 1 - Paradigmas de Linguagens de Programação – 05N 
 
Nós, 

Lucas Micael Accorsi Freitas da Silva TIA: 41552881
Thiago Valença Corrêa TIA: 31885731
 
declaramos que 
 
todas as respostas são fruto de nosso próprio trabalho,
não copiamos respostas de colegas externos à equipe,
não disponibilizamos nossas respostas para colegas externos ao grupo e
não realizamos quaisquer outras atividades desonestas para nos beneficiar ou prejudicar
outros.
*/

public class Main {
    public static void main(String[] args) {
        Scanner resposta = new Scanner(System.in);
        listaPonto teste1 = new listaPonto(10);
        int x,y,indice,resultado;

        while(true){
          System.out.print("\n////////////////////////// Bem Vindo ////////////////////////////// \n");
          System.out.print("0. Sair.\n");
          System.out.print("1. Adicionar um elemento no final da coleção.\n");
          System.out.print("2. Adicionar um elemento em uma posição da coleção.\n");
          System.out.print("3. Retornar o índice da primeira ocorrência de um elemento especificado na coleção.\n");
          System.out.print("4. Remover um elemento em uma posição na coleção.\n");
          System.out.print("5. Calcular a distância dos dois pontos mais distantes na coleção;\n");
          System.out.print("6. Retornar uma coleção de pontos contido em uma circunferência.\n");
          System.out.print("///////////////////////////////////////////////////////////////////\n");

          System.out.print("Digite uma das Opções: ");
          int opcao = resposta.nextInt();
          if(opcao == 0){
            break;
          }
          switch(opcao){
            case 1:
              System.out.print("Digite a coordenada x do ponto: ");
              x = resposta.nextInt();
              System.out.print("Digite a coordenada y do ponto: ");
              y = resposta.nextInt();
              Ponto p1 = new Ponto(x,y);
              teste1.adcionaFinal_Ponto(p1);
              break;

            case 2:
              System.out.print("Digite a coordenada x do ponto: ");
              x = resposta.nextInt();
              System.out.print("Digite a coordenada y do ponto: ");
              y = resposta.nextInt();
              System.out.print("Digite o Indice que deseja colocar: ");
              indice = resposta.nextInt();
              Ponto p2 = new Ponto(x,y);
              teste1.adciona_Ponto(p2, indice);
              break;

            case 3:
              System.out.print("Digite a coordenada x do ponto: ");
              x = resposta.nextInt();
              System.out.print("Digite a coordenada y do ponto: ");
              y = resposta.nextInt();
              Ponto p3 = new Ponto(x,y);
              resultado = teste1.procura_Indice(p3);
              System.out.println("O indice é "+ resultado);
              break;

            case 4:
              System.out.print("Digite o Indice que deseja colocar: ");
              indice = resposta.nextInt();
              teste1.remover_Ponto(indice);
              break;

            case 5:
              teste1.calcula_Maior_Distancia();
              break;

            case 6:
              System.out.print("Digite a coordenada x do ponto central: ");
              x = resposta.nextInt();
              System.out.print("Digite a coordenada y do ponto central: ");
              y = resposta.nextInt();
              System.out.print("Digite o valor do raio: ");
              double raio = resposta.nextInt();
              Ponto p4 = new Ponto(x,y);
              teste1.pontos_Circuferencia(raio, p4);
              break;

            default:
              System.out.println("Erro de Input");
          }
          System.out.println("Status da Lista:");
          teste1.printa_Lista();
        }
    }
}
