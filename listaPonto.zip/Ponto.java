package Main;

public class Ponto{
    private int x, y;
    
    public Ponto( int x, int y){
        this.x = x;
        this.y = y;
    }

    @Override
    public String toString() {
        return "Ponto{" + "x=" + x + ", y=" + y + '}';
    }

    public boolean verifica_Igual(Ponto c2){
        return this.x == c2.x && this.y == c2.y;
    }
    
    // Calcula a distancia de dois pontos.
    public  double calcula_Distancia(Ponto c2){
        double resposta;
        resposta = Math.sqrt(Math.pow(c2.x - this.x, 2) + Math.pow(c2.y - this.y, 2));
        return resposta;
    }
    
    // Verifica qual ponto é maior.
    public  Ponto maior(Ponto c2){
        if (c2.x + c2.y > this.x + this.y){
            return c2;
        }else{
          return this;
        }
    }
    
    // Verifica qual ponto é menor.
    public  Ponto menor(Ponto c2){
        if (c2.x + c2.y < this.x + this.y){
            return c2;
        }else{
          return this;
        }
    }
}