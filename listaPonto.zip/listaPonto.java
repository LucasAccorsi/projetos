package Main;

public class listaPonto{
    private Ponto pontos[];
    private int validos;

    // Contrutor
    public listaPonto(int n){
        this.pontos = new Ponto[n];
        this.validos = 0;
    }

    
    public void adcionaFinal_Ponto(Ponto p){
        if(this.validos != 10){
            this.pontos[this.validos] = p;
            this.validos++;
        }
    }
    
    // Adciona ponto em indice informado se possivel
    public void adciona_Ponto(Ponto p,int indice){
        if(this.validos == 0){ // Se não tiver pontos no vetor
            this.pontos[0] = p; // Adicionar na primeira posição o ponto
            this.validos++;
        }else if(this.validos != 10){ // Se já tiver pontos no vetor
            if(indice > this.validos){ // Se o indice for maior que a quantidade de pontos no vetor
                this.pontos[this.validos] = p; // Adicionar na proxima posição livre
                this.validos++;
            }else{ // Se o indice for menor que a quantidade de pontos no vetor
                for(int aux = this.validos-1; aux != indice; aux--){ // reajustar o vetor
                    this.pontos[aux+1] = this.pontos[aux];
                }
                this.pontos[indice] = p; // colocar ponto no indice informado
                this.validos++;
            }
        }
    }

    public int procura_Indice(Ponto p){
        for(int i = 0; i < this.validos; i++){
            if(p.verifica_Igual(this.pontos[i]) == true ){ // Utilizando função do ponto
                return i;
            }
        }
        return -1;
    }

    public void remover_Ponto(int indice){
        if(this.validos >= indice){
            if(indice == 9){ // Verifica se é a ultima posição
                this.pontos[indice] = null;
                this.validos--;
            }else{
                for(;this.pontos[indice] != null; indice++){ // reajustar o vetor
                    this.pontos[indice] = this.pontos[indice+1];
                    if (indice == 8){ // Checa se está na penultima posição
                        this.pontos[indice+1] = null;
                    }
                }
                this.validos--;
            }
        }
    }
  
    public void calcula_Maior_Distancia(){
        if(this.validos > 1){ // Se tiver pelomenos dois pontos no vetor
            Ponto ponto_Maior = this.pontos[this.validos-1], ponto_Menor = this.pontos[this.validos-1];
            for(int i = 0; i < this.validos; i++){ // Procurar maior e menor número
                ponto_Maior = ponto_Maior.maior(this.pontos[i]); // Utilizando função do ponto
                ponto_Menor = ponto_Menor.menor(this.pontos[i]); // Utilizando função do ponto
            }
            System.out.println(ponto_Maior);
            System.out.println(ponto_Menor);
            System.out.println(ponto_Maior.calcula_Distancia(ponto_Menor)); // Utilizando função do ponto
        }
    }

    public void pontos_Circuferencia(double raio, Ponto circuferencia){
        for(int i = 0; i < this.validos; i++){
            double distancia = circuferencia.calcula_Distancia(this.pontos[i]);
            if(distancia <= raio){
                System.out.println(this.pontos[i] + " ");
            }
        }
    }

    public void printa_Lista(){
        for(int i=0; i < 10; i++){
            System.out.print(this.pontos[i] + " ");
        }
    }
}