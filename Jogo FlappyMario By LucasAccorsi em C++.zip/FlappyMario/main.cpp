#include <sstream>
#include <string.h>
#include <time.h>
using namespace std;
#include "recursos/bin/include/Graphics.hpp"
#include "recursos/bin/include/Audio.hpp"
#include "recursos/bin/include/SFML/Graphics/Color.hpp"
using namespace sf;
#include "recursos/Collision.cpp"
#include "flappy_mario_private.h"


const int alturaCima = 0;
const int alturaBaixo = 385;
int continu = 0;
int acab = 0;
int cont=0;
Text text;
RectangleShape rectangle;
	

struct Point{
	int x,y;
} mario, cima[5], baixo[5];

void resetar(){
	continu = 1;
	acab = 1;
	cont = 0;
    mario.x = 100;
    mario.y = 205;
    
    text.setPosition(615,35);
	rectangle.setSize(Vector2f(50, 50));
	rectangle.setPosition(602,37);
    
    cima[0].y = (rand()%140)-350;
    baixo[0].y = cima[0].y + 600;
    cima[0].x = 1300;
    baixo[0].x = 1300;
    for(int i=1; i<5; i++){
    	cima[i].y = (rand()%140)-350;
    	baixo[i].y = cima[i].y + 600;
    	cima[i].x = cima[i-1].x + 300;
    	baixo[i].x = cima[i].x;
	}
}
int main(){
	
    srand(time(0));
    
    Image icon;
	icon.loadFromFile("recursos/flappy_mario.png");
    RenderWindow window(VideoMode(1300, 480), "Flappy Mario");
    Vector2u img(icon.getSize());
    window.setIcon(img.x, img.y, icon.getPixelsPtr());
    
    Color vermelho(255, 0, 0);
    Color branco(255, 255, 255);
    String str;
    
    Font font;
	font.loadFromFile("../recursos/fonte/arial.ttf");
    text.setFont(font);
	text.setCharacterSize(42);
	text.setStyle(Text::Bold);
	text.setColor(branco);
	rectangle.setFillColor(vermelho);
	rectangle.setOutlineColor(branco);
	rectangle.setOutlineThickness(5);
	
    
	Texture t1,t2,t3,t4,t5;
    t1.loadFromFile("../recursos/imagens/mario.png");
    t2.loadFromFile("../recursos/imagens/BG.png");
    t3.loadFromFile("../recursos/imagens/canoBaixo.png");
    t4.loadFromFile("../recursos/imagens/canoCima.png");
    t5.loadFromFile("../recursos/imagens/gameOver.png");
	Sprite s(t1), background(t2), frameBaixo(t3), frameCima(t4), acabou(t5);
	s.setTexture(t1);
	frameBaixo.setTexture(t3);
    frameCima.setTexture(t4);
    acabou.setPosition(300, 50);
    

    int dy=0;
    std::ostringstream aux;
    resetar();
    
    float timer=0,delay=0.03; 
    Clock clock;
    
    while (window.isOpen()){
    
		float time = clock.getElapsedTime().asSeconds();
        clock.restart();
        timer+=time;
        
    	Event e;
        while (window.pollEvent(e)){
            if (e.type == Event::Closed)
                window.close();
            
			if (e.type == Event::KeyPressed)
              	if (continu == 0)
				  	if (e.key.code==Keyboard::Up||e.key.code==Keyboard::W)
				  		mario.y += -35;
				if(e.key.code==Keyboard::Space){
					if(acab == 0)	
						resetar();
			  		continu = 0;
			  	}
			  		
		}
		if (continu == 0){
			if (timer>delay){
				mario.y+=2.8;
         		for(int i=0; i<5; i++){
    				cima[i].x += -5;
    				baixo[i].x += -5;
				}
      			timer=0;
      		}
		}
        
		window.clear(Color::White);
        window.draw(background);
        s.setPosition(mario.x, mario.y);
		window.draw(s);
		
		for(int i=0; i<5; i++){
        	
        	if(cima[i].x == -120){
        		cima[i].y = (rand()%140)-350;
    			baixo[i].y = cima[i].y + 570;
    			cima[i].x = 1350;
    			baixo[i].x = cima[i].x;
    			cont++;
    			
			}
			
			frameBaixo.setPosition(baixo[i].x, baixo[i].y);
        	frameCima.setPosition(cima[i].x, cima[i].y);
        	window.draw(frameBaixo);
        	window.draw(frameCima);
        	
			if (Collision::PixelPerfectTest(s, frameBaixo, 0) || Collision::PixelPerfectTest(s, frameCima, 0)){		
				acab = 0;
				continu = 1;
        	}
    	}
    	
        if (alturaBaixo < mario.y || alturaCima >= mario.y){
			acab = 0;
			continu = 1;
        }
        if(acab == 0)
			window.draw(acabou);
			
		if (cont > 9 && cont < 100){
    		rectangle.setSize(Vector2f(57, 50));
			rectangle.setPosition(592,37);
			text.setPosition(598,35);
		}else if(cont > 99 && cont < 1000){
    		rectangle.setSize(Vector2f(75, 50));
			rectangle.setPosition(589,37);
			text.setPosition(590,35);
		}else if(cont > 1000){
    		rectangle.setSize(Vector2f(130, 50));
			rectangle.setPosition(579,37);
			text.setPosition(580,35);
		}
		
		window.draw(rectangle);
		aux << cont;
		str = aux.str();
		aux.str("");
		aux.clear();
		
		text.setString(str);
		window.draw(text);
		window.display();
    	
	}
    return 0;
}
