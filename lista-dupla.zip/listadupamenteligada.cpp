#include <iostream>
#include "listaduplamenteligada.h"

#include <stdlib.h>
template <typename E>
ListaDuplamenteLigada<E>::ListaDuplamenteLigada(){
  cabeca = fim = NULL;
}

template <typename E>
ListaDuplamenteLigada<E>::~ListaDuplamenteLigada(){
  delete cabeca;
}

template <typename E>
bool ListaDuplamenteLigada<E>::vazia() const{
  return (cabeca == NULL);
}

template <typename E>
const E& ListaDuplamenteLigada<E>::inicio() const{
  return cabeca -> elem;
}

template <typename E>
const E& ListaDuplamenteLigada<E>::final() const{
  return fim -> elem;
}

template <typename E>
void ListaDuplamenteLigada<E>::insereInicio(const E& e){
  DNo<E>*aux = new DNo<E>();
  aux -> prev = NULL;
  aux -> elem = e;
  if(vazia()){
    aux -> prox = NULL;
    cabeca = fim = aux; 
  }else{
    aux -> prox = cabeca;
    cabeca -> prev = aux;
    cabeca = aux;
  }
}

template <typename E>
void ListaDuplamenteLigada<E>::insereFinal(const E& e){
  DNo<E> *aux = new DNo<E>();
  aux -> prox = NULL;
  aux -> elem = e;
  if(vazia()){
    aux -> prev = NULL;
    fim = cabeca = aux; 
  }else{
    aux ->  prev = fim;
    fim -> prox = aux;
    fim = aux;
  }
}

template <typename E>
void ListaDuplamenteLigada<E>::removeInicio(){
  if(cabeca == fim){
    delete cabeca;
  }else{
    DNo<E> *aux = cabeca;
    cabeca = cabeca -> prox;
    cabeca -> prev = NULL;
    delete aux;
  }
}

template <typename E>
void ListaDuplamenteLigada<E>::removeFinal(){
  if(fim == cabeca){
    delete fim;
    fim = cabeca = NULL; 
  }else{
    DNo<E> *aux = fim;
    fim = fim -> prev;
    fim -> prox = NULL;
    delete aux;
  }
}

template <typename E>
const void ListaDuplamenteLigada<E>::elementos(){
  if(vazia()){
    std::cout <<"\nEla está vazia";
  }else{
    for (DNo<E>*aux = cabeca; aux != NULL; aux  = aux -> prox){
      std::cout <<"\n" << aux->elem;
    }
  }
}

template <typename E>
const E ListaDuplamenteLigada<E>::soma(){
  E aux1 = cabeca->elem;
  for (DNo<E>*aux = cabeca; aux != NULL; aux = aux -> prox){
    aux1 = aux1 + aux->elem;
  }
  return aux1;
}