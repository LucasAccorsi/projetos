#include <iostream>
#include "listadupamenteligada.cpp"

int main() {
  
  int i,f,menu=1;
  ListaDuplamenteLigada<int>l;
  
  while(menu!=0){
  		std::cout << "\nSAIR 0 \nInsere Inicio 1 \nInsere Final 2 \nRemove Inicio 3 \nRemove Final 4 \nVazia 5 \nElemento do Inicio 6 \nElemento do Final 7 \nElementos da Lista 8 \nSoma de Elementos 9 \nOPÇÃO: ";
		std::cin >> menu;
  	
	  	switch(menu){
  			case 1:
  				std::cout << "\nNumero do Inicio: ";
  				std::cin >> i;
  				l.insereInicio(i);
  				break;
  			case 2:
  				std::cout << "\nNumero do Final: ";
  				std::cin >> f;
  				l.insereFinal(f);
  				break;
  			case 3:
  				l.removeInicio();
  				break;
  			case 4:
  				l.removeFinal();
  				break;
  			case 5:
  				std::cout << l.vazia();
  				break;
  			case 6:
  				std::cout << "\n" << l.inicio();
  				break;
  			case 7:
  				std::cout << "\n" << l.final();
  				break;
        case 8:
          l.elementos();
          break;
        case 9:
          std::cout << "\n" << l.soma();
          break;
		}
	}
}