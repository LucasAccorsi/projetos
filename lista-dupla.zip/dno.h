#ifndef DNO_H
#define DNO_H

template <typename E>
class ListaDuplamenteLigada;

template <typename E>
class DNo{
  private:
    E elem;
    DNo<E>*prox;
    DNo<E>*prev;
    friend class ListaDuplamenteLigada<E>;
};

#endif