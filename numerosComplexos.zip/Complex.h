#ifndef	COMPLEX_H
#define	COMPLEX_H

class	Complex{
  private:
    double a, b;
    char sinal;
  public:
  	Complex(double va, double vb, char sinal);
    ~Complex();
    double getA();
    double getB();
    Complex operator+(Complex n);
    Complex operator-(Complex n);
    Complex operator*(Complex n);
};
#endif