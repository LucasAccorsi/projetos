#include <iostream>
#include "Racional.h"

int main(){
  Racional a(3, 2,'-');
  Racional b(5, 3, '+');
  std::cout << a.getA() << '/' << a.getB() << "\n";
  std::cout << b.getA() << '/' << b.getB();
  
  return 0;
}