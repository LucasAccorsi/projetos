#include "Complex.h"
#include	<stdlib.h>
#include <iostream>

Complex::Complex(double va, double vb, char sinal){
  a = va;
  b = vb;
  if (sinal=='+'){
    a = va;
  }
  else if (sinal == '-'){
    a = -va;
  }
}
Complex::~Complex(){}

double	Complex::getA(){
  return a;
}	
	
double	Complex::getB(){
  return b;
}	
	
Complex Complex::operator+(Complex	n){
  double va = a+n.getA();
  double vb = b+n.getB();
  Complex s(abs(va), abs(vb), (va/vb)<0?'-':'+');
  return s;
}	
	
Complex Complex::operator-(Complex n){
  double va = a-n.getA();
  double vb = b-n.getB();
  Complex s(abs(va), abs(vb), (va/vb)<0?'-':'+');
  return	s;
}

Complex Complex::operator*(Complex n){
  double va = ((a * n.getA()) - (b * n.getB()));
  double vb = ((a * n.getB()) - (b * n.getA()));;
  Complex s(abs(va), abs(vb), (va/vb)<0?'-':'+');
  return	s;
}