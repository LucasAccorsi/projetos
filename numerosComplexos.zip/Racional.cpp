#include "Racional.h"
#include <stdlib.h>	
	
Racional::Racional(int va, int vb, char sinal):Complex(va, vb, sinal){
  a = va;
  b = vb;
  if (sinal=='+'){
    a = va;
  }
  else if (sinal == '-'){
    a = -va;
  }
}
	
Racional::~Racional(){}

int	Racional::getA(){
  return a;
}	
	
int	Racional::getB(){
  return b;
}	
	
Racional Racional::operator+(Racional	n){
  int	va =	a + n.getA();
  int	vb = b * n.getB();
  Racional s(abs(va), abs(vb), (va/vb)<0?'-':'+');
  return s;
}	
	
Racional Racional::operator-(Racional	n){
  int va = a - n.getA();
  int vb = b * n.getB();
  Racional s(abs(va), abs(vb), (va/vb)<0?'-':'+');
  return	s;
}

Racional Racional::operator*(Racional	n){
  int va = a * n.getA();
  int vb = b * n.getB();
  Racional s(abs(va), abs(vb), (va/vb)<0?'-':'+');
  return	s;
}