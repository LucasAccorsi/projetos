#ifndef	RACIONAL_H
#define	RACIONAL_H	
#include "Complex.h"

class	Racional:public Complex{
  private:
    double a, b;
    char sinal;
  public:
  	Racional(int va, int vb, char sinal);
    ~Racional();
    int	getA();
    int	getB();
    Racional operator+(Racional n);
    Racional operator-(Racional n);
    Racional operator*(Racional n);
};
#endif