#ifndef ARVORE_H
#define ARVORE_H
#include "No.h"

#include <iostream>
using namespace std;

class Arvore{

  private:
	  No *raiz;

  public:
	  Arvore(){
	    raiz = NULL;
    }
    
    void inserir(int chave){
    	if(raiz == NULL){
		    raiz = new No(chave);
      }
      else
	      inserirAux(raiz, chave);
    }
    
    void inserirAux(No *no, int chave){
      if(chave == no->getChave()){
        no->igual();
      }else if(chave < no->getChave()){
		    if(no->getEsq() == NULL){
			  No *novo_no = new No(chave);
			  no->setEsq(novo_no);
		    }
		    else{
		    inserirAux(no->getEsq(), chave);
	      }
      }
      else if(chave > no->getChave()){
  	    if(no->getDir() == NULL){
			    No *novo_no = new No(chave);
			    no->setDir(novo_no);
		    }
  	    else{
			    inserirAux(no->getDir(), chave);
		    }
	    }
    }
    
    No* getRaiz(){
	    return raiz;
    }

    void imprimeRaiz(){
	    cout<< "\n raiz = "<<raiz->getChave();
    }

    void setRaiz(No *no){
	    raiz = no;
    }

    void preOrdem(No* no){
	    if(no != NULL){
        cout << no->getChave() << " ";
	      preOrdem(no->getEsq());
		    preOrdem(no->getDir());
	    }
    }
    
    bool Buscaelem(No* no, int e){
	    if(no != NULL){
        return  (no->getChave() == e);
        }
        Buscaelem(no->getEsq(),e);
		    Buscaelem(no->getDir(),e);
    }

    void posOrdem(No* no){
	    if(no != NULL){
	      posOrdem(no->getEsq());
		    posOrdem(no->getDir());
        cout << no->getChave() << " ";
      }
    }
    
    No *removeraiz (No *r){
      No *p, *q;
      /*if(r->getOcorrencias() > 1){
        r->removeriguais();
      }else*/ if (r->getEsq() == NULL){
        q = r->getDir();
   		  free (r);
        return q;
      }
      p = r;
      q = r->getEsq();
      while (q->getDir() != NULL){
 	 	    p = q;
        q = q->getDir();
      }
      if (p != r){
      	p->setDir(q->getEsq());
      	q->setEsq(r->getEsq());
      }
      q->setDir(r->getDir());
  	  free (r);
  	  return q;
    }
    
    No* excluirNo(int number, No* no){
      if (number == no->getChave()){
        return removeraiz (no);
      }else if((number < no->getChave()) && (no->getEsq() != NULL)){
        return excluirNo(number, no->getEsq());
      }else if((number > no->getChave()) && (no->getDir() != NULL)){
        return excluirNo(number, no->getDir());
      }
      return NULL;
    }
    
    void menorelemento(No* no){
      if(no->getEsq() != NULL){
        return menorelemento(no->getEsq());
      }
      cout << "O menor elemento é: " << no->getChave();
    }
    
    void localizar(int number, No* no){
      if (number == no->getChave()){
        cout << "\nElemento está nessa posição: " << no->getChave() <<" numero de ocorrencias é: " << no->getOcorrencias();
      }else if((number < no->getChave()) && (no->getEsq() != NULL)){
        cout << "\nElemento está a esquerda do: " << no->getChave();
        return localizar(number, no->getEsq());
      }else if((number > no->getChave()) && (no->getDir() != NULL)){
        cout << "\nElemento está a direita do: " << no->getChave();
        return localizar(number, no->getDir());
      }else{
        cout << "\nO elemento Não está na arvore";
      }
    }int tamanho(No* no){
      if (no ==  NULL){
        return 0;
      }
      int esq = tamanho(no->getEsq());
      int dir = tamanho(no->getDir());
      
      return esq+1;
      return dir+1;

      if (dir > esq){
        return dir;
      }else{
        return esq;
      }
    }

    int segundoMaior(No *r){
        No *aux = r->getDir();
        if(aux->getDir() == NULL){
          if(r->getEsq() == NULL){
            return r->getChave();
          }
          else{
            No *aux2 = r->getEsq();
            return aux2->getChave();
          }
        }
        else{
          return segundoMaior(aux);
        }
    }

};
#endif