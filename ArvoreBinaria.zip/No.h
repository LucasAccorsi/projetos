#ifndef NO_H
#define NO_H

class No{
  private:
	  No *esq, *dir;
	  int chave, cont;

  public:
	  No(int chave){
		  this->chave = chave;
      cont = 1;
		  esq = NULL;
		  dir = NULL;
    }
    
    int getChave(){
    	return chave;
    }
    int getOcorrencias(){
    	return cont;
    }

    No* getEsq(){
	    return esq;
    }
    No* getDir(){
	    return dir;
    }
    
    void setEsq(No *no){
	    esq = no;
    }
    void setDir(No *no){
	    dir = no;
    }

    void igual(){
	    cont = cont + 1;
    }
    void removeriguais(){
      cont = cont - 1;
    }
};

#endif