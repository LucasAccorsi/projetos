#include <iostream>
#include "Arvore.h"
#include "No.h"

using namespace std;

int main(int argc, char *argv[]){
	Arvore arv;
  while (true) {
  cout << "\n ----------------------- \n ARVORE BINARIA DE BUSCA \n ----------------------- \n0 - sair\n1 - incluir um no\n2 - localizar um no\n3 - excluir raiz\n4 - imprimir a arvore em Pre Ordem\n5 - imprimir a arvore Em Ordem\n6 - imprimir a arvore em Pos Ordem\n7 - menor elemento\n8 - altura da árvore\n9 - excluir um no\n\nSua opcao -> ";
	int opc;
	cin >> opc;
  if (opc == 0){
		break;
	}else if (opc == 1){
		int opc1;
			cout << "\n Informe o valor do no a ser incluido: ";
			cin >> opc1;
      arv.inserir(opc1);
			system("pause");
		}else if (opc == 2){
			int opc2;
			cout << "\n Informe o valor do no a ser localizado: ";
			cin >> opc2;
			arv.localizar(opc2, arv.getRaiz());
			system("pause");
		}else if (opc == 3){
			arv.setRaiz(arv.removeraiz(arv.getRaiz()));
      system("pause");
		}else if (opc == 4){
			arv.preOrdem(arv.getRaiz());
      cout << "\n\n";
      system("pause");
		}else if (opc == 5){
			cout << arv.Buscaelem(arv.getRaiz(),5);
      cout << "\n\n";
      system("pause");
		}else if (opc == 6){
			arv.posOrdem(arv.getRaiz());
      cout << "\n\n";
      system("pause");
		}else if (opc == 7){
      arv.menorelemento(arv.getRaiz());
			system("pause");
		}else if (opc == 8){
      cout << arv.tamanho(arv.getRaiz());
			system("pause");
		}else if (opc == 9){
      int opc9;
		  cout << "\n Informe o valor do no a ser excluido: ";
			cin >> opc9;
      No* aux;
      aux = arv.excluirNo(opc9, arv.getRaiz());
      if (aux != NULL){
        arv.setRaiz(aux);
      }
			system("pause");
		}
    else if (opc == 10){
      cout << arv.segundoMaior(arv.getRaiz());
    }
  }
  cout << "\n\nObrigado e até breve.\n\n";
  return 0;
}