#include	<iostream>
#include	"VETOR.h"

template	<typename	T>
Vetor<T>::Vetor(int	t){
	v=new	T[t];
	if	(v==NULL)
		throw	new	std::string("memoria	insuficiente");
	tam=t;
}

template	<typename	T>
Vetor<T>::~Vetor(){
	delete	v;
}					

template	<typename	T>
int	Vetor<T>::tamanho(){
	return	tam;
}

template	<typename	T>
T	Vetor<T>::elemento(int i){
  if((i<0)||(i>=tam))
    throw new std::string("Indice Inválido");
	return	v[i];
}

template	<typename	T>
bool	Vetor<T>::procura(T elem){
  for(int i; i<tam; i++){
    if(elem==v[i])
	    return	true;
  }
  return	false;
}

template	<typename	T>
void Vetor<T>::insere(T d, int i){
  if((i<0)||(i>=tam))
    throw new std::string("Indice Inválido");
	v[i]=d;
}

template	<typename	T>
void Vetor<T>::remove(int i){
  if((i<0)||(i>=tam)) {
    throw new std::string("Indice Inválido");
}
for(int j=i; j < tam -1; j++)
  v[j] = v[j+1];
  
v[tam -1] = NULL;
}