#include <iostream>
#include "VETOR.cpp"

int main() {
  int tamanhova, tamanhovb;
  
  std::cout << "Tamanho do Vetor A: ";
  std::cin >> tamanhova;
  std::cout << "Tamanho do Vetor B: ";
  std::cin >> tamanhovb;

  Vetor<int> a(tamanhova);
  Vetor<int> b(tamanhovb);
  Vetor<int> c(a.tamanho()+b.tamanho());

  std::cout << "Vetor A: ";
  for (int i=0; i<a.tamanho(); i++){
    a.insere(i+1,i);
    std::cout << " " << a.elemento(i);
  }
  std::cout << "\n";

  std::cout << "Vetor B: ";
  for (int i=0; i<b.tamanho(); i++){
    b.insere(i+1+a.tamanho(),i);
    std::cout << " " << b.elemento(i);
  }
  std::cout << "\n";
  
  std::cout << "Vetor junto: ";
  for (int i=0; i<c.tamanho(); i++){
    if(i < a.tamanho())
      c.insere(a.elemento(i),i);
    else
      c.insere(b.elemento(i-a.tamanho()),i);
  }

  for (int i=0; i<c.tamanho(); i++)
    std::cout << " " << c.elemento(i);
    
return 0;
}