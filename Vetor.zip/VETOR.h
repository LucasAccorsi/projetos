#ifndef	VETOR_H
#define	VETOR_H
template	<typename	T>
class	Vetor{
	private:
		T*	v;					//	vetor	de	elementos	do tipo	T
		int	tam;		//	tamanho	do	vetor
	public:
		Vetor(int	t);
		~Vetor();
		int	tamanho();
		T	elemento(int	i);
		bool procura(T	elem);
		void insere(T d,int i);
		void remove(int	i);
};
#endif