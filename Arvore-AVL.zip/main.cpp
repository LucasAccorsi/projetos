#include <iostream>
#include "AVLNode.h"
#include "AVLTree.h"

using namespace std;

int main(){
  AVLNode arv;
  while (true){
    cout << "\n ----------------------- \n ARVORE AVL \n----------------------- \n0 - sair\n1 - incluir um no\n2 - imprimir a arvore em Pre Ordem\n3 - imprimir a arvore Em Ordem\n4 - imprimir a arvore em Pos Ordem\n5 - altura da árvore\n\nSua opcao -> ";
	  int opc;
	  cin >> opc;
    if (opc == 0){
		  break;
	  }else if (opc == 1){
		  int opc1;
			cout << "\n Informe o valor do no a ser incluido: ";
			cin >> opc1;
      arv.inserir(opc1);
			system("pause");
		}else if (opc == 2){
			arv.preOrder(arv.getRoot());
      cout << "\n\n";
      system("pause");
		}else if (opc == 3){
			arv.inOrder(arv.getRoot());
      cout << "\n\n";
      system("pause");
		}else if (opc == 4){
			arv.posOrder(arv.getRoot());
      cout << "\n\n";
      system("pause");
		}else if (opc == 5){
      cout << arv.getHeight();
			system("pause");
		}
			system("pause");
		}
  cout << "\n\nObrigado e até breve.\n\n";
  return 0;
}